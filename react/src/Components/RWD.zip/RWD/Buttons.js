import React from 'react'

function RWDEx03() {
    return (
        <div className="row">
        <button className="btn btn-default ">Button</button>
        <button className="btn btn-primary">Button</button>
        <button className="btn btn-secondary">Button</button>
        <button className="btn btn-success">Button</button>
        <button className="btn btn-danger">Button</button>
        <button className="btn btn-info">Button</button>
        <button className="btn btn-warning">Button</button>
        <button className="btn btn-link">Button</button>
    </div>
    )
}

export default RWDEx03
